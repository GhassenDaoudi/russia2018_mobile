/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.Service;

import com.codename1.io.ConnectionRequest;
import com.codename1.io.NetworkManager;
import com.mycompany.Entite.EquipeFantasy;

/**
 *
 * @author quickstrikes96
 */
public class ServiceEquipeFantasy {
    
    public void ajoutEquipe(EquipeFantasy eq) {
        ConnectionRequest con = new ConnectionRequest();
        String Url = "http://localhost/russia2018_web-master/RS2018/web/mobile/new/"+eq.getNom();
        con.setUrl(Url);

        System.out.println("tt");

        con.addResponseListener((e) -> {
            String str = new String(con.getResponseData());
            System.out.println(str);
//            if (str.trim().equalsIgnoreCase("OK")) {
//                f2.setTitle(tlogin.getText());
//             f2.show();
//            }
//            else{
//            Dialog.show("error", "login ou pwd invalid", "ok", null);
//            }
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
    }
    
}
