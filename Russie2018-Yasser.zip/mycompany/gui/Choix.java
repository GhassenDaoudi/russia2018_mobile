/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gui;

import com.codename1.components.ImageViewer;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.EncodedImage;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.Toolbar;
import com.codename1.ui.URLImage;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.table.TableLayout;
import com.mycompany.Entite.Equipe;
import com.mycompany.Entite.EquipeFantasy;
import com.mycompany.Entite.Joueur;
import com.mycompany.Entite.JoueurFantasy;
import com.mycompany.Entite.User;
import com.mycompany.Service.ServiceEquipe;
import com.mycompany.Service.ServiceJoueur;
import com.mycompany.Service.ServiceJoueurFantasy;
import java.util.ArrayList;

/**
 *
 * @author quickstrikes96
 */
public class Choix {
    Form f2;
    Button btnadd;
    
    
    public Choix(){
        f2 = new Form("Equipes Nationales", BoxLayout.y());
        ServiceEquipe SE = new ServiceEquipe();
        ServiceJoueur SJ = new ServiceJoueur();
        //f2 = new Form("Joueurs",new TableLayout(74,4));
        
                    ArrayList<Equipe> LE= SE.afficherEquipes();
                    for (Equipe equipe : LE) {
                        Container C1 = new Container(new BoxLayout(BoxLayout.X_AXIS));
                        Container C2 = new Container(new BoxLayout(BoxLayout.X_AXIS));
                    EncodedImage placeholder1 = EncodedImage.createFromImage(Image.createImage(60, 60, 0xffff2700), true);
                    Image i3 = URLImage.createToStorage(placeholder1, equipe.getDrapeau(), "http://localhost/PI/Flags/"+equipe.getDrapeau(), URLImage.RESIZE_SCALE_TO_FILL); 
                    ImageViewer iv3 = new ImageViewer(i3);
                    Label sp = new Label(equipe.getNom());
                    C1.setLeadComponent(sp);
                    ArrayList<Joueur> LJ= SJ.afficherJoueurs();                  
                    sp.addPointerPressedListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent evt) {
                    
                    Form f1 = new Form(equipe.getNom(),new TableLayout(74,5));
                    Toolbar tb = f1.getToolbar();
                    tb.addMaterialCommandToLeftBar("Back", FontImage.MATERIAL_ARROW_BACK, e -> {
                        f2.showBack();
                    });
                    for (Joueur joueur : LJ){
                    if (joueur.getEquipe().getNom().equals(equipe.getNom())){
                        EncodedImage placeholder1 = EncodedImage.createFromImage(Image.createImage(60, 60, 0xffff2700), true);
                    Image i4 = URLImage.createToStorage(placeholder1, joueur.getImage(), "http://localhost/PI/image/"+joueur.getImage(), URLImage.RESIZE_SCALE_TO_FILL); 
                    ImageViewer iv4 = new ImageViewer(i4);
                    Label spn = new Label(joueur.getNom()+" "+joueur.getPrenom());
                    Label sp4 = new Label(String.valueOf(joueur.getPosteF()));
                    Label sp5 = new Label(String.valueOf(joueur.getPrix()));
                    btnadd = new Button("Ajouter");
                    f1.add(iv4);
                    f1.add(spn);
                    f1.add(sp4);
                    f1.add(sp5);
                    f1.add(btnadd);
                    btnadd.addActionListener((e) -> {
            ServiceJoueurFantasy ser = new ServiceJoueurFantasy();
            JoueurFantasy j = new JoueurFantasy();
            EquipeFantasy eq =new EquipeFantasy();
            eq.setId(30);
            j.getJoueur().setId(joueur.getId());
            j.getFEquipes().setId(eq.getId());
            j.setEtat(1);
            j.setPoints(0);
            ser.ajoutJoueur(j.getJoueur(),j.getFEquipes(),j.getEtat(),j.getPoints());

        });
                    }
                    
                    
                }
                    f1.show();
                    }
            });

                    C2.add(sp);
                    C1.add(iv3);
                    C1.add(C2);
                    f2.add(C1);
                    
 
    }
                    f2.show();
                  /*  Toolbar tb = f2.getToolbar();
                    tb.addMaterialCommandToLeftBar("Statistiques", FontImage.MATERIAL_ARROW_FORWARD, e -> {
        
                         Statistiques stq = new Statistiques();
                         stq.getF().show();
                    });
                    ArrayList<Joueur> LJ= SJ.afficherJoueurs();
                    for (Joueur joueur : LJ) {
                    EncodedImage placeholder1 = EncodedImage.createFromImage(Image.createImage(60, 60, 0xffff2700), true);
                    Image i3 = URLImage.createToStorage(placeholder1, joueur.getImage(), "http://localhost/PI/image/"+joueur.getImage(), URLImage.RESIZE_SCALE_TO_FILL); 
                    ImageViewer iv3 = new ImageViewer(i3);
                    Label spn = new Label(joueur.getNom()+""+joueur.getPrenom());
                    Label sp4 = new Label(String.valueOf(joueur.getPosteF()));
                    Label sp5 = new Label(String.valueOf(joueur.getPrix()));
               
                    f1.add(iv3);
                    f1.add(sp);
                    f1.add(sp4);
                    f1.add(sp5);
                    f1.show();
 
    }*/
    }
    
    
    
        public Form getF() {
        return f2;
    }

    public void setF(Form f) {
        this.f2 = f;
    }
    
}
