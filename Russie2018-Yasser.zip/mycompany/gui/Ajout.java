/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gui;

import com.codename1.messaging.Message;
import com.codename1.ui.Button;
import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.mycompany.Entite.EquipeFantasy;
import com.mycompany.Entite.User;
import com.mycompany.Service.ServiceEquipeFantasy;
import com.mycompany.utils.Stats;

/**
 *
 * @author quickstrikes96
 */
public class Ajout {
    
    Form f;
    TextField tnom;
    Button btnajout;

    public Ajout() {
        Stats s = new Stats();
        f = new Form("Saisir Le Nom de Votre Equipe");
        tnom = new TextField();
        btnajout = new Button("Valider");
        f.add(tnom);
        
        f.add(btnajout);
        btnajout.addActionListener((e) -> {
            ServiceEquipeFantasy ser = new ServiceEquipeFantasy();
            User u = new User();
            EquipeFantasy eq = new EquipeFantasy(tnom.getText(), 0, 0, u, 0, 0, 100 );
            ser.ajoutEquipe(eq);
           // Message m = new Message("Tfadhel");
            //Display.getInstance().sendMessage(new String[] {"yasseraziz.hajji@esprit.tn"}, "Haw mail", m);
            Choix c=new Choix();
            c.getF().show();
            

        });
    }

    public Form getF() {
        return f;
    }

    public void setF(Form f) {
        this.f = f;
    }

    public TextField getTnom() {
        return tnom;
    }

    public void setTnom(TextField tnom) {
        this.tnom = tnom;
    }
    
}
